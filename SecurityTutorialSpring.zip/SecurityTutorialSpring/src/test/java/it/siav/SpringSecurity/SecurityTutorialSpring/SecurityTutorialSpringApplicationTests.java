package it.siav.SpringSecurity.SecurityTutorialSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurityTutorialSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
