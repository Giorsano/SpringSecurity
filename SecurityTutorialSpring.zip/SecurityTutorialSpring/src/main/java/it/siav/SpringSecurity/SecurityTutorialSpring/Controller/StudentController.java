package it.siav.SpringSecurity.SecurityTutorialSpring.Controller;

import it.siav.SpringSecurity.SecurityTutorialSpring.model.Student;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
public class StudentController {

    @GetMapping("/students")
    public List<Student> studentList(){
        List<Student> students = new ArrayList<>();

        Student student1 = new Student();
        student1.setId(1);
        student1.setFirstName("Mario");
        student1.setLastName("Rossi");

        Student student2 = new Student();
        student2.setId(2);
        student2.setFirstName("Carlo");
        student2.setLastName("Verdi");

        Student student3 = new Student();
        student3.setId(3);
        student3.setFirstName("Nicola");
        student3.setLastName("Bianchi");

        students.add(student1);
        students.add(student2);
        students.add(student3);

        return students;
    }


    @PostMapping("/students")
    public Student createStudent(@RequestBody Student student){
        studentList().add(student);
        return student;
    }
}
