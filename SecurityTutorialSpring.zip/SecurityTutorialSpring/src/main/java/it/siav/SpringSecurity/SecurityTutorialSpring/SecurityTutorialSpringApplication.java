package it.siav.SpringSecurity.SecurityTutorialSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityTutorialSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityTutorialSpringApplication.class, args);
	}

}
