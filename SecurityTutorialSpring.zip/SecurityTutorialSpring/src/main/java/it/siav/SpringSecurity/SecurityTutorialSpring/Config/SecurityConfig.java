package it.siav.SpringSecurity.SecurityTutorialSpring.Config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration //annotazione che indica che questa è una classe di configurazione
@EnableWebSecurity //indica  che questa classe abilita la sicurezza web.
public class SecurityConfig {
@Bean
SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception{
    http
            .authorizeHttpRequests((requests) -> requests //questo metodo della classe HttpSecurity configura quale richieste HTTP sono autorizzate
                    .requestMatchers("/", "/home").permitAll() //in questo caso le richieste a "/" e "/home" sono permesse a tutti
                    .anyRequest().authenticated()). //mentre le altre devono essere autenticate
            formLogin((form)->form.loginPage("/login").permitAll())//configura il modulo di accesso, in questo caso la pagina di accesso è "/login" ed è aperta a tutti
            .logout((logout) -> logout.permitAll()); //configura il modulo di logout, in questo caso è permesso a tutti

    return http.build(); //restituisce la catena di filtri creata
    }
    /**
     * Bisogna creare un bean che che crea un metodo Security Filter Chain che è una serie di filtri che controlla l'accesso a pagine web.
     * Il parametro HttpSecurity è la classe che permette di configurare la sicurezza Http.
     * Il Security Filter Chain è la prima cosa che Spring Boot va a cercare.
      **/


    @Bean
    public UserDetailsService userDetailsService(){
        UserDetails user = User //crea un istanza di UserDetails
                .withDefaultPasswordEncoder()
                .username("user") //con username user
                .password("password") //con password pass
                .roles("USER") //con il ruolo USER
                .build(); //e me lo buildi

        return new InMemoryUserDetailsManager(user); //gestisce le credenziali dell'utente in memoria.
    }

    // in questo caso creiamo un solo utente. Possiamo fare anche una lista di utenti e settarli oppure utilizzare un database e riportare tutto sul UserDetailService attraverso le query.
}
